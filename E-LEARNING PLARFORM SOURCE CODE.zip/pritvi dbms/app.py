from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database connection configuration
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='darshan2146',
        database='e-learning'
    )

# Home route, will show the login page
@app.route('/')
def index():
    return render_template('index.html')

# Login route, authenticates users based on email and password (assuming you have a password in Students)
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']  # Assuming you have a password field
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Students WHERE Email = %s AND Password = %s', (email, password))
        student = cursor.fetchone()
        conn.close()

        if student:
            session['student_id'] = student[0]  # Store the student ID in the session
            return redirect(url_for('courses'))
        else:
            return 'Invalid credentials. Please try again.'
    return render_template('login.html')

# Courses route
@app.route('/courses')
def courses():
    if 'student_id' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Courses')
    courses = cursor.fetchall()
    conn.close()
    return render_template('courses.html', courses=courses)

# Instructors route
@app.route('/instructors')
def instructors():
    if 'student_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Instructors')
    instructors = cursor.fetchall()
    conn.close()
    return render_template('instructors.html', instructors=instructors)

# Progress route
@app.route('/progress')
def progress():
    if 'student_id' not in session:
        return redirect(url_for('login'))

    student_id = session['student_id']
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''SELECT Courses.Title, Progress.CompletionStatus, Progress.Grade 
                      FROM Progress 
                      JOIN Courses ON Progress.CourseID = Courses.CourseID 
                      WHERE Progress.StudentID = %s''', (student_id,))
    progress = cursor.fetchall()
    conn.close()
    return render_template('progress.html', progress=progress)

# Enroll route (student enrolls in a course)
@app.route('/enroll/<int:course_id>', methods=['GET', 'POST'])
def enroll(course_id):
    if 'student_id' not in session:
        return redirect(url_for('login'))

    student_id = session['student_id']
    conn = get_db_connection()
    cursor = conn.cursor()

    # Check if the student is already enrolled
    cursor.execute('SELECT * FROM Enrollments WHERE StudentID = %s AND CourseID = %s', (student_id, course_id))
    existing_enrollment = cursor.fetchone()
    
    if existing_enrollment:
        return 'You are already enrolled in this course.'
    
    cursor.execute('INSERT INTO Enrollments (StudentID, CourseID, EnrollmentDate, Status) VALUES (%s, %s, NOW(), "Active")', 
                   (student_id, course_id))
    conn.commit()
    conn.close()
    return redirect(url_for('courses'))

# Logout route
@app.route('/logout')
def logout():
    session.pop('student_id', None)  # Remove the student_id from session
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
